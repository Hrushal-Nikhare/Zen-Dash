import requests
import concurrent.futures
import requests

cookies = {
    '__Secure-authjs.callback-url': 'https^%^3A^%^2F^%^2Fhyperplexed.io',
    'anon': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJqTWRwUFNsUTQ3dUsiLCJpYXQiOjE3NDAwNTE3NDcwMDksInN0YXR1cyI6InZlcmlmaWVkIiwiZXhwIjoxNzcxNjA5MzQ3fQ.eti2oEPzUwYK2Ptq4iPiojdq6PBiG9tRqfJRYazYuvY',
    'ph_phc_7cCG2GnbCBDmTxEaLstiei57EWg0pwgs6fxBtoNlQbi_posthog': '^%^7B^%^22distinct_id^%^22^%^3A^%^220195232a-82cb-7010-b0c2-a8a181888d00^%^22^%^2C^%^22^%^24sesid^%^22^%^3A^%^5B1740051743600^%^2C^%^220195232a-82c9-7320-9d73-45d52436850f^%^22^%^2C1740051743433^%^5D^%^2C^%^22^%^24initial_person_info^%^22^%^3A^%^7B^%^22r^%^22^%^3A^%^22https^%^3A^%^2F^%^2Fwww.youtube.com^%^2F^%^22^%^2C^%^22u^%^22^%^3A^%^22https^%^3A^%^2F^%^2Fhyperplexed.io^%^2Fevents^%^2Flive-thumbnail^%^22^%^7D^%^7D',
}

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Referer': 'https://hyperplexed.io/events/live-thumbnail',
    'Content-Type': 'application/json',
    'Origin': 'https://hyperplexed.io',
    'Sec-GPC': '1',
    'Connection': 'keep-alive',
    # 'Cookie': '__Secure-authjs.callback-url=https^%^3A^%^2F^%^2Fhyperplexed.io; anon=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJqTWRwUFNsUTQ3dUsiLCJpYXQiOjE3NDAwNTE3NDcwMDksInN0YXR1cyI6InZlcmlmaWVkIiwiZXhwIjoxNzcxNjA5MzQ3fQ.eti2oEPzUwYK2Ptq4iPiojdq6PBiG9tRqfJRYazYuvY; ph_phc_7cCG2GnbCBDmTxEaLstiei57EWg0pwgs6fxBtoNlQbi_posthog=^%^7B^%^22distinct_id^%^22^%^3A^%^220195232a-82cb-7010-b0c2-a8a181888d00^%^22^%^2C^%^22^%^24sesid^%^22^%^3A^%^5B1740051743600^%^2C^%^220195232a-82c9-7320-9d73-45d52436850f^%^22^%^2C1740051743433^%^5D^%^2C^%^22^%^24initial_person_info^%^22^%^3A^%^7B^%^22r^%^22^%^3A^%^22https^%^3A^%^2F^%^2Fwww.youtube.com^%^2F^%^22^%^2C^%^22u^%^22^%^3A^%^22https^%^3A^%^2F^%^2Fhyperplexed.io^%^2Fevents^%^2Flive-thumbnail^%^22^%^7D^%^7D',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Priority': 'u=0',
    # Requests doesn't support trailers
    # 'TE': 'trailers',
}

data = '{"option":"purple"}'

response = requests.post('https://hyperplexed.io/api/events/1aAC/vote', cookies=cookies, headers=headers, data=data)
print(response.text)

def request_post():
    requests.post('https://hyperplexed.io/api/events/1aAC/vote', cookies=cookies, headers=headers, data=data)


with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(request_post) for _ in range(1000)]
        concurrent.futures.wait(futures)
