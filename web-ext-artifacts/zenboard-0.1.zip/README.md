# ZenDash

### v0.1

To build the extension, run the following command in the terminal:

```bash
web-ext build --overwrite-dest
```

make sure you have the web-ext installed, if not, you can install it by running the following command:

```bash
npm install --global web-ext
```

to run the extension in the browser, run the following command in the terminal:

```bash
web-ext run
```
